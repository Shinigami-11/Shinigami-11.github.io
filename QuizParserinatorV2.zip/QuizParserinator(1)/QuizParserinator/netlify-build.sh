#!/bin/bash

# Simple build script for Netlify deployment

echo "🔨 Building your app for Netlify..."
npm run build

echo "📝 Copying redirects file..."
node copy-redirects.js

echo "✅ Build complete!"
echo "🚀 Your app is ready for Netlify deployment!"
echo "Simply drag and drop the 'dist' folder to app.netlify.com/drop"
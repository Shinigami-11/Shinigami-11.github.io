/**
 * This script copies the _redirects file to the dist folder
 * after the build is complete
 */

const fs = require('fs');
const path = require('path');

// Paths
const redirectsSource = path.join(__dirname, '_redirects');
const distFolder = path.join(__dirname, 'dist');
const redirectsTarget = path.join(distFolder, '_redirects');

// Make sure dist folder exists
if (!fs.existsSync(distFolder)) {
  console.error('Error: dist folder does not exist. Run npm run build first.');
  process.exit(1);
}

// Copy _redirects file
try {
  fs.copyFileSync(redirectsSource, redirectsTarget);
  console.log('✅ _redirects file copied to dist folder');
} catch (error) {
  console.error('Error copying _redirects file:', error);
  process.exit(1);
}

console.log('🚀 Your app is ready for Netlify deployment!');
console.log('Simply drag and drop the "dist" folder to app.netlify.com/drop');
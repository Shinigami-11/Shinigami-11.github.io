import { InsertQuestion, Question } from '@shared/schema';

const STORAGE_KEY = 'userQuestions';

/**
 * Retrieves all user-added questions from localStorage
 */
export function getUserQuestions(): Question[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error reading questions from localStorage:', error);
    return [];
  }
}

/**
 * Saves a new question to localStorage
 */
export function saveUserQuestion(question: InsertQuestion): Question {
  try {
    const questions = getUserQuestions();
    const maxId = questions.length > 0 
      ? Math.max(...questions.map(q => q.id))
      : 0;
    
    const newQuestion: Question = {
      ...question,
      id: maxId + 1
    };
    
    const updatedQuestions = [...questions, newQuestion];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedQuestions));
    
    return newQuestion;
  } catch (error) {
    console.error('Error saving question to localStorage:', error);
    throw new Error('Failed to save question');
  }
}

/**
 * Deletes a question from localStorage by ID
 */
export function deleteUserQuestion(id: number): boolean {
  try {
    const questions = getUserQuestions();
    const updatedQuestions = questions.filter(q => q.id !== id);
    
    if (questions.length === updatedQuestions.length) {
      return false; // No question was removed
    }
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedQuestions));
    return true;
  } catch (error) {
    console.error('Error deleting question from localStorage:', error);
    return false;
  }
}

/**
 * Updates an existing question in localStorage
 */
export function updateUserQuestion(id: number, updatedData: Partial<InsertQuestion>): Question | null {
  try {
    const questions = getUserQuestions();
    const questionIndex = questions.findIndex(q => q.id === id);
    
    if (questionIndex === -1) {
      return null;
    }
    
    const updatedQuestion = {
      ...questions[questionIndex],
      ...updatedData
    };
    
    questions[questionIndex] = updatedQuestion;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(questions));
    
    return updatedQuestion;
  } catch (error) {
    console.error('Error updating question in localStorage:', error);
    return null;
  }
}

/**
 * Imports multiple questions at once into localStorage
 */
export function importUserQuestions(questions: InsertQuestion[]): Question[] {
  try {
    const existingQuestions = getUserQuestions();
    let maxId = existingQuestions.length > 0 
      ? Math.max(...existingQuestions.map(q => q.id))
      : 0;
    
    const newQuestions = questions.map(question => {
      maxId++;
      const newQuestion: Question = { ...question, id: maxId };
      return newQuestion;
    });
    
    const allQuestions = [...existingQuestions, ...newQuestions];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(allQuestions));
    
    return newQuestions;
  } catch (error) {
    console.error('Error importing questions to localStorage:', error);
    throw new Error('Failed to import questions');
  }
}

/**
 * Clears all user questions from localStorage
 */
export function clearUserQuestions(): boolean {
  try {
    localStorage.removeItem(STORAGE_KEY);
    return true;
  } catch (error) {
    console.error('Error clearing questions from localStorage:', error);
    return false;
  }
}
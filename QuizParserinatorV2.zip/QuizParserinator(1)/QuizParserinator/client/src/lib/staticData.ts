import { Question, QuizDifficulty, QuizSubject } from '@shared/schema';

// This file contains static data to make the app work
// without requiring a backend server

// Sample questions for the quiz
export const staticQuestions: Question[] = [
  {
    id: 1,
    difficulty: QuizDifficulty.DISTRICT,
    subject: QuizSubject.SCIENCE,
    year: '2023',
    text: 'This element with atomic number 79 is often used in jewelry and electronics due to its high conductivity and resistance to corrosion.',
    answer: 'Gold'
  },
  {
    id: 2,
    difficulty: QuizDifficulty.REGIONAL,
    subject: QuizSubject.MATH,
    year: '2024',
    text: 'This mathematician, born in 1887 in India, is known for his work on number theory and made significant contributions despite having almost no formal training.',
    answer: 'Srinivasa Ramanujan'
  },
  {
    id: 3,
    difficulty: QuizDifficulty.STATE,
    subject: QuizSubject.ARTS,
    year: '2022',
    text: 'This painting by Leonardo da Vinci, completed around 1503, is one of the most famous portraits ever created and is housed in the Louvre Museum.',
    answer: 'Mona Lisa'
  },
  {
    id: 4,
    difficulty: QuizDifficulty.DISTRICT,
    subject: QuizSubject.SOCIAL,
    year: '2023',
    text: 'This document, signed in 1776, declared the thirteen American colonies independent from Great Britain.',
    answer: 'Declaration of Independence'
  },
  {
    id: 5,
    difficulty: QuizDifficulty.REGIONAL,
    subject: QuizSubject.LANGUAGE,
    year: '2024',
    text: 'This literary device involves giving human characteristics to non-human entities.',
    answer: 'Personification'
  },
  {
    id: 6,
    difficulty: QuizDifficulty.STATE,
    subject: QuizSubject.SCIENCE,
    year: '2022',
    text: 'This theory, proposed by Albert Einstein in 1915, describes gravity as a geometric property of space and time.',
    answer: 'General Relativity'
  },
  {
    id: 7,
    difficulty: QuizDifficulty.DISTRICT,
    subject: QuizSubject.MATH,
    year: '2023',
    text: 'This mathematical constant, approximately equal to 3.14159, represents the ratio of a circle\'s circumference to its diameter.',
    answer: 'Pi'
  },
  {
    id: 8,
    difficulty: QuizDifficulty.REGIONAL,
    subject: QuizSubject.ARTS,
    year: '2024',
    text: 'This Dutch post-impressionist painter created "Starry Night" and cut off part of his own ear.',
    answer: 'Vincent van Gogh'
  },
  {
    id: 9,
    difficulty: QuizDifficulty.STATE,
    subject: QuizSubject.SOCIAL,
    year: '2022',
    text: 'This 1954 Supreme Court case overturned the "separate but equal" doctrine and ruled that racial segregation in public schools was unconstitutional.',
    answer: 'Brown v. Board of Education'
  },
  {
    id: 10,
    difficulty: QuizDifficulty.DISTRICT,
    subject: QuizSubject.LANGUAGE,
    year: '2023',
    text: 'This punctuation mark is used to join independent clauses and to separate items in a complex series.',
    answer: 'Semicolon'
  }
];

// Get questions from local storage or fallback to static questions
export function getStoredQuestions(): Question[] {
  try {
    const storedQuestions = localStorage.getItem('userQuestions');
    if (storedQuestions) {
      return [...JSON.parse(storedQuestions), ...staticQuestions];
    }
  } catch (error) {
    console.error('Error reading from localStorage:', error);
  }
  return staticQuestions;
}

// Store a new question in local storage
export function storeQuestion(question: Omit<Question, 'id'>): Question {
  try {
    const storedQuestions = localStorage.getItem('userQuestions');
    let questions: Question[] = storedQuestions ? JSON.parse(storedQuestions) : [];
    
    // Generate a new ID (max existing ID + 1)
    const maxId = questions.reduce((max, q) => Math.max(max, q.id), 1000);
    const newQuestion: Question = { ...question, id: maxId + 1 };
    
    questions.push(newQuestion);
    localStorage.setItem('userQuestions', JSON.stringify(questions));
    
    return newQuestion;
  } catch (error) {
    console.error('Error writing to localStorage:', error);
    // Fallback with a random ID if localStorage fails
    return { ...question, id: Math.floor(Math.random() * 10000) + 1000 };
  }
}

// Save score to local storage
export function saveScore(score: number): void {
  try {
    localStorage.setItem('userScore', score.toString());
  } catch (error) {
    console.error('Error saving score to localStorage:', error);
  }
}

// Get score from local storage
export function getScore(): number {
  try {
    const storedScore = localStorage.getItem('userScore');
    return storedScore ? parseInt(storedScore, 10) : 0;
  } catch (error) {
    console.error('Error reading score from localStorage:', error);
    return 0;
  }
}
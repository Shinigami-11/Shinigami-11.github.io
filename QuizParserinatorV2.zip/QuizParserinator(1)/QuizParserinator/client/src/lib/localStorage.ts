/**
 * Enhanced local storage utilities to make the app work without a backend
 * This file provides a simple interface for storing and retrieving data
 * from localStorage with error handling and type safety
 */

// Generic function to get an item from localStorage
export function getItem<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    if (item === null) {
      return defaultValue;
    }
    return JSON.parse(item);
  } catch (error) {
    console.error(`Error getting ${key} from localStorage:`, error);
    return defaultValue;
  }
}

// Generic function to set an item in localStorage
export function setItem<T>(key: string, value: T): boolean {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    console.error(`Error setting ${key} in localStorage:`, error);
    return false;
  }
}

// Remove an item from localStorage
export function removeItem(key: string): boolean {
  try {
    localStorage.removeItem(key);
    return true;
  } catch (error) {
    console.error(`Error removing ${key} from localStorage:`, error);
    return false;
  }
}

// Clear all items from localStorage
export function clearStorage(): boolean {
  try {
    localStorage.clear();
    return true;
  } catch (error) {
    console.error('Error clearing localStorage:', error);
    return false;
  }
}

// Check if an item exists in localStorage
export function hasItem(key: string): boolean {
  return localStorage.getItem(key) !== null;
}

// Get all keys from localStorage
export function getAllKeys(): string[] {
  try {
    return Object.keys(localStorage);
  } catch (error) {
    console.error('Error getting all keys from localStorage:', error);
    return [];
  }
}

// Export a direct localStorage interface for components that need it
export const storage = {
  getItem,
  setItem,
  removeItem,
  clearStorage,
  hasItem,
  getAllKeys
};